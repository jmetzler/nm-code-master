const  {Logger, LEVELS} = require('../logger');
var stripAnsi = require('strip-ansi');
var assert = require('assert');
const fs = require('fs');
var yaml = require('js-yaml');
var chalk = require('chalk');

describe('Logger', function () {
    describe('constructor', function () {       
        it('is passed root parameter of driver', function () {
            var rootLog = new Logger({root: 'driver'});
            assert.equal(rootLog.root, "driver");            
        });      
        it('is passed an override function for transport the transport function is changed and the output matches the change', function() {
            var transportLog = new Logger({ transport(level, message) {
                if(level && message){
                    return true;
                }
            }});
            assert.equal(transportLog.transport('debug', 'test'), true);
        });       
        it('is passed an override function for the format function then the format function is changed and output matches the change', function() {
            var formatLog = new Logger({
                format(logObj) {
                    if(logObj){
                        return true;
                    }
                }
            });
            assert.equal(formatLog.format('This is the string to be formated'), true);     
        });
    });
    describe('#log', function () {        
        it('is passed an object with a message property the output should be {"root":"driver","message":"starting the app","level":"info"}', function() {
            var rootLog = new Logger({root: 'driver'});         
            console.log('test');
            var oldLog = console.log;
            var result;
            console.log = function(message){
                result = message;
                //return message;
                //for some reason this was not working not sure why.
            } 
            rootLog.log({ message: 'starting the app' });
            console.log = oldLog; 
            assert.equal(stripAnsi(result), '{"root":"driver","message":"starting the app","level":"info"}');            
        });        
        it('is passed a string message and a ERROR log level the output should be {"root":"driver","message":"an error occured","level":"error"}', function() {
            var rootLog = new Logger({root: 'driver'});
            var oldLog = console.log;
            var result;
            console.log = function(message){
                if(message){
                    result = message;
                }
            }
            rootLog.log('an error occured', 'error');
            console.log = oldLog;
            assert.equal(stripAnsi(result), '{"root":"driver","message":"an error occured","level":"error"}');
        });
    });
    describe('#createLogObject', function () {
        it('creates a object based on root and the level output should be "{root:"driver", level: "info"}"', function() {
            var rootLog = new Logger({root: 'driver'});
            var test = rootLog.createLogObject();
            assert.equal(JSON.stringify(test), JSON.stringify({ root: 'driver', level: 'info' }));
        });
    });
    describe('#format', function () {       
        it('is passed an object it outputs the json string of the object', function() {
            var mockJSON = '{"test":"this is content"}';
            var mockObject = {test: 'this is content'};
            var rootLog = new Logger({root: 'driver'});
            assert.equal(rootLog.format(mockObject), mockJSON);            
        });        
        it('is overrided and it outputs a yaml file', function() {           
            var mockLogObj = {test: "this is a test message."};
            var formatLog =  new Logger({
                format(logObj) {
                    return yaml.safeDump(logObj);
                }
            });
            assert.equal(formatLog.format(mockLogObj), "test: this is a test message.\n");           
        });
    });
    describe('#transport', function () {       
        it('is passed a level and message it outputs the message to console', function() {
            var oldLog = console.log;
            var rootLog = new Logger({root: 'driver'});
            var result;
           console.log = function(message){
                if(message){
                    result = message;
                }               
           }          
           rootLog.transport('debug', 'this is a test message');
           console.log = oldLog;
           assert.equal(stripAnsi(result), 'this is a test message');
        });           
        //not sure how to specifically look for color to level. How to map ansi to the color.
        it('is passed a debug level and a message the output is of that message and color',function(){
            var oldLog = console.log;
            var rootLog = new Logger({root: 'driver'});
            var result = [];
            console.log = function(message){
                if(message){
                    result = message;
                }               
            }          
            rootLog.transport('debug', 'this is a test message');
            console.log = oldLog;
            assert.equal(chalk.hasColor(result), true);
        });
    });
});
