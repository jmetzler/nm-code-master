//require('../logger');

describe('Logger', function() {

});